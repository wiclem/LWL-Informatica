<?php

@session_start();
include ('seguranca.php');
seguranca_adm();
include ('cliente/menus/menu_cliente.php');
include ('paginainicial.php');




