<?php

include ('seguranca.php');
seguranca_adm();
include ('menus/menu_adm.php');
include ('paginainicial.php');