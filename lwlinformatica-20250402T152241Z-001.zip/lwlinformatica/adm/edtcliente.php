<?php

@session_start();
include('conexao.php');
include('menu.php');

$idcliente = $_GET['idcliente'];

$sql = "select * from tblcliente where idcliente='$idcliente'";

$qry = mysqli_query($con,$sql);

$resultado = mysqli_fetch_array($qry);

$cliente = $resultado['nome'];
$datareg = $resultado['cpf'];

//echo $idcliente." - ".$cliente." - ".$datareg; 
?>

<div class="container">
<h1>Atualizar Cliente</h1>
<form action="uptcliente.php" method="post">
      
                        <input type="hidden" name="idcliente" value="<?php echo $idcliente ?>">
      cliente           <input type="text" name="nome" value="<?php echo $cliente ?>">
      data de registro  <input type="text" name="cpf" value="<?php echo $datareg ?>">
                        <input type="submit" value="Atualizar Registro" class="btn btn-primary">