<?php
include ('seguranca.php');
seguranca_adm();
include ('menus/menu_cliente.php');
include ('paginainicial.php');




