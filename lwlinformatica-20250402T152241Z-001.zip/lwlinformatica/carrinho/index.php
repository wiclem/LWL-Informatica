

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title></title>
    </head>

    <body>
    <?php
          require("conexao.php");
         
          $sql = "SELECT * FROM tblexibeprod";
          $qry = mysqli_query($con,$sql);
          while($ln = mysqli_fetch_array($qry)){
             echo '
<h2>'.$ln['produto'].'</h2>

';
             echo 'Preço : R$ '.number_format($ln['preco'], 2, ',', '.').'
';
             echo '<img src="../img/'.$ln['foto'].'" width="100px" height="100px">
';
             echo '<a href="carrinho.php?acao=add&id='.$ln['idproduto'].'">Comprar</a>';
             echo '
<hr />

';
          }
    ?>

    </body>

    </html>
