<?php 

$senha = 123;
$senha = md5($senha);

echo $senha;