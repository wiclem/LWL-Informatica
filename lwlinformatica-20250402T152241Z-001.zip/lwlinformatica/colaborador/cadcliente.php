<?php
@session_start();
include('menus/menu_colaborador.php');
include('conexao.php');
include('seguranca.php');
seguranca_adm();
?>
    
  <head>

   <style type="text/css">
  body { background-image: url(img/body.jpg); }
  .container
  { background-color:  #F0F8FF; }
  
  </style>


    <title>..:: Cadastro ::..</title>
  </head>
  
  <body>
  
    <div class="container">
    <br>
    <br>
        <h1>Cadastro</h1>

    <hr>

      <form action="inscliente.php" method="POST">
          
              <div class="row">
                <div class="col-md-8">
              <div class="form-group">
                <label>Nome</label>
                    <input type="text" class="form-control" name='nome'>  
             </div>
             </div>               
    

            <div class="col-md-4">
            <div class="form-group">
              <label>CPF</label>
              <input type="text" class="form-control" name='cpf'>
            </div> 
            </div> 
            </div> 
               

            <div class="form-group">
              <label>E-mail</label>
              <input type="text" class="form-control" name='email'>
            </div>    


            <div class="row">
                <div class="col-md-6">
            <div class="form-group">
              <label>Senha</label>
              <input type="password" class="form-control" name='senha'>
            </div>  
            </div>  
              

             <div class="col-md-6">
            <div class="form-group">
              <label>Confirmar Senha</label>
              <input type="password" class="form-control" name='cpf'>
            </div>
            </div>
            </div>

              <div class="form-group">
              <label>Telefone</label>
              <input type="text" class="form-control" name='telefone'>
            </div>        
    
    
            <button type="submit" class="btn btn-primary">Cadastrar cliente</button>
    </form>   

</div>   

  </body>

<?php
@include("rodape.php");
?>
