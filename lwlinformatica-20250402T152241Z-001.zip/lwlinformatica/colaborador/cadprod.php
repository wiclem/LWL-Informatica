<?php 
@session_start();
include ('conexao.php')
?>
<html>  <!-- cadnoticias.php -->
  <head>
    <title>CKEditor</title>
    <meta content="text/html; charset=utf-8" http-equiv="content-type" />
    <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
    <script type="text/javascript">
      window.onload = function()  {
        CKEDITOR.replace( 'produto' );
     };
    </script>
  </head>
  <body>
    <form action="salvarprod.php" method="post">
      Produto <input type="text" name="produto"><br>
      Foto <input type="file" name="foto"><br>
      preco <input type="text" name="preco"><br>
     
 Descrição <br>
 <textarea id="idproduto" name="produto">&lt;p&gt;Valor inicial.&lt;/p&gt;</textarea>
      <input type="submit" value="Cadastrar Produto" />
    </form>  
  </body>
</html>
