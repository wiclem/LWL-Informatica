<?php

@session_start();
include ('seguranca.php');
include ('menus/menu_colaborador.php');
include ('paginainicial.php');




