<?php include ('conexao.php'); ?>
<body>
<hr>

<div id="rodape" class="centralizar">
	<p>&copy; LWL. | FT <a href="#">Informática</a> 
		| Sistemas <a href="#" rel="nofollow">LTDA</a>.</p>
</div>
<body>